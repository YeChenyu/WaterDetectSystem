package com.jida.activity.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

import com.jida.base.BaseActivity;
import com.jida.base.CallBack;
import com.jida.waterdetect.R;



public class TestActivity extends BaseActivity {
    private static final String TAG = "MainActivity";
    private Context mContext = TestActivity.this;
//    private SerialPort mPort = new SerialPort();

    @Override
    protected void onClickEsc() {
        //串口通信测试
//        try {
//            mPort.write(StringUtil.hexStr2Bytes("020004F1012F0103D9"));
//            byte[] data = new byte[256];
//            int ret = mPort.read(data, 5000);
//            Log.d("TAG", "opreaPort: receiver="+ StringUtil.byte2HexStr(data));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        //网络请求测试
//        try {
//            HttpClientUtil.getInstance()
//                    .getSyncString("http://yecy.free.ngrok.cc/TestWeb/MainServlet.do");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        HttpClientUtil.getInstance()
//                .getAsyn("http://yecy.free.ngrok.cc/TestWeb/MainServlet.do",
//                        new OkHttpResultCallback<String>() {
//                            @Override
//                            public void onError(Request request, Exception e) {
//                                Log.e("TAG", "onClickEsc: "+ request.urlString());
//                                e.printStackTrace();
//                            }
//
//                            @Override
//                            public void onResponse(String response) {
//                                Log.d("TAG", "onClickEsc: "+ response);
//                            }
//                        });

        //数据库存储测试
//        DBManager.getInstance().getDaoSession().getTestDao().deleteAll();
//        long result = DBManager.getInstance().getDaoSession().getTestDao().insert(new Test(0l, true, 12, "haha"));
//        Log.d(TAG, "onClickEsc: "+ result);
//        for (int i=0 ; i<5 ; i++){
//            long id = DBManager.getInstance().getDaoSession().getTestDao().loadAll().size();
//            result = DBManager.getInstance().getDaoSession().getTestDao().insert(new Test(id, true, 12, "haha"));
//            Log.d(TAG, "onClickEsc: "+ result);
//        }
//        List<Test> lstTest = DBManager.getInstance().getDaoSession().getTestDao().loadAll();
//        for (Test test : lstTest){
//            Log.d(TAG, "onClickEsc: "+ test.toString());
//        }

        //Excel导入导出测试
//        ExcelManager.getInstance().exportExcelFile(mContext);
        //XML配置文件读写
//        ComPort port = new ComPort("COM1", 115200, 1, 0, 8);
//        Server servera = new Server("servera", "192.168.1.1", "123456", "8080");
//        Server serverb = new Server("serverb", "192.168.1.1", "123456", "8080");
//        Server serverc = new Server("serverc", "192.168.1.1", "123456", "8080");
//        NetWork netWork = new NetWork(1, "192.168.1.1", "", "", "", "", 1, 1, 1, 1,
//                servera, serverb, serverc);
//        ServerSite serverSite = new ServerSite("XXX", "1", "122.12", "32.11", "12332323", 1, 1);
//        System system = new System("1234567890", serverSite, netWork, port);
//        XMLUtil.toXML(system, "/mnt/test.xml");

        //对话框测试
//        displayDialogProgress("正在检测SD卡...", 3000);
        View v = LayoutInflater.from(mContext).inflate(R.layout.setting_password, null);
        displayDialogCustom("导入中...", v, "", new CallBack.OnBasicListener() {
            @Override
            public void onConfirm() {

            }

            @Override
            public void onCancel() {

            }
        });
//        displayDialogSucc("导出成功！", new CallBack.OnCompleteListener() {
//            @Override
//            public void onComplete() {
//            }
//        });
    }

    @Override
    protected void addContentView() {
        setContentView(R.layout.main_activity);
//        setCustomViewEnable(true);
//        setTitle("Main Activity");

    }

    @Override
    protected void initView() {
//        try {
//            mPort.openSerialPort(new File("/dev/s3c2410_serial0"), 115200);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        mPort.closeSerialPort();
    }
}
