package com.jida.db.xml;

/**
 * Created by chenyuye on 17/12/5.
 */

public interface IDevice {

}
