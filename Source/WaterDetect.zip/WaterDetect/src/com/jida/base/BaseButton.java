package com.jida.base;

import android.annotation.SuppressLint;
import android.content.Context;
import android.widget.Button;

@SuppressLint("AppCompatCustomView")
public class BaseButton extends Button {

	public BaseButton(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	
}
